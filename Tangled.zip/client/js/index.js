const socket = io();

import Controller from "./controller.js";
const Cont = new Controller(document.getElementById("canvas"));

import Engine from "./engine.js";
const Eng = new Engine(50);

import DisplayMan from "./display.js";
const DM = new DisplayMan(document.getElementById("canvas"));

import AssetMan from "./AssetManager.js";
const AM = new AssetMan();

import MersenneTwister from './mersenne.js';

import GameManager from './GameManager.js';
const GM = new GameManager({
  nodeCount: 10,
  minLinks: 1,
  useFixed: false,
  randomSeed: 0,
  sck: socket
});

AM.batchLoad([
  { id:"Node", type:"Image", path:"./assets/Node-2.png" },
  { id:"NodeShadow", type:"Image", path:"./assets/NodeBut.png" },
  { id:"BG1", type:"Image", path:"./assets/BG1-2.png" },
  { id:"Menu", type:"Image", path:"./assets/Menu.png" },
  { id:"GM", type:"Image", path:"./assets/InGame-2.png" },
  { id:"Solved", type:"Image", path:"./assets/Done-2.png" },
  { id:"Info", type:"Image", path:"./assets/Info-2.png" }
], ()=>{  Eng.run(); })



//test
Eng.addUpdateFunction(()=>{
  //gameManager.update();
  GM.updateGame(Cont,DM);
 });

Eng.addDrawFunction(()=>{
   DM.drawImage({ img:AM.getAsset("BG1") , x:0, y:0 });
   //gameManager.drawAll();
   GM.drawGame(AM,DM);
   DM.update(); //Draws the Double Buffer to the canvas
 });
