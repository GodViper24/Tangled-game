const express = require('express');
const app = express();
const port = process.env.PORT || 8080;
const Database = require("@replit/database");
const db = new Database();

const socket = require('socket.io');

db.get("Link").then((v)=>{
 if( v == undefined ){
   db.set("Link","Good");
   //console.log("Link added!");
 } else {
   //console.log("DB found!");
 }
});



app.use((req,res,next)=>{
  //console.log("Logging request...");
  //console.log(req.ip+" "+req.path);
  next();
});

app.use("/client",express.static(__dirname+"/client"));
app.use("/css",express.static(__dirname+"/client/css"));
app.use("/html",express.static(__dirname+"/client/html"));
app.use("/js",express.static(__dirname+"/client/js"));
app.use("/assets",express.static(__dirname+"/client/assets"));

app.get('/',(req,res)=>{
  res.sendFile(__dirname+'/client/html/index.html');
});

// app.get('/purge',(req,res)=>{
//   db.list().then((k)=>{
//     k.forEach((cv)=>{ db.delete(cv); });
//   });
// });

const server = app.listen(port,()=>{
  console.log("Server running on port: "+port);
});

// db.list().then(keys => {
//   keys.forEach((k)=>{ console.log(k); });
// });

const io = socket(server);

io.on("connection",(sck)=>{
 console.log("Socket Connected");
  sck.on("SetScore",(Data)=>{
    //console.log("Set Score Called...");
    db.get(Data.GameID).then((value)=>{
      if(value == undefined || value == null){
        db.set(Data.GameID,{ Score:Data.Score, Time:Data.Time }).then(()=>{
          console.log("New record set: "+Data.GameID+" : "+Data.Score+" : "+Data.Time);
        });
      } else if( value.Score > Data.Score || (value.Score == Data.Score && value.Time > Data.Time ) ) {
        db.set(Data.GameID,{ Score:Data.Score, Time:Data.Time }).then(()=>{
          console.log("New record set: "+Data.GameID+" : "+Data.Score+" : "+Data.Time);
        });
      }
    });
  });

  sck.on("GetScore",(GameID)=>{
    //console.log("Getting Score for: "+GameID);
    db.get(GameID).then((value)=>{
      //console.log("Score: "+value);
      if(value == undefined) { sck.emit("Score",{ score:-1 });  }
      else {
        sck.emit("Score",{ score:value.Score, time:value.Time });
      }
    });
  });
  
 });