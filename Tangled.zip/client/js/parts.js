class Particle {
  constructor(x,y,c,vx,vy,life,r = 2 ){
    this.x = x;
    this.y = y;
    this.c = c;
    this.vx = vx;
    this.vy = vy;
    this.life = life;
    this.r = r;
  }
  update(){
    if(this.life <= 0 ){ return; }
    this.x += this.vx;
    this.y += this.vy;
    this.life -= 1;
  }
  draw(ctx){
    if(this.life <= 0){ return; }
    ctx.fillStyle = this.c;
    ctx.beginPath();
    ctx.arc(this.x,this.y,this.r,0,2*Math.PI);
    ctx.fill();
    ctx.closePath();
  }
}

export default class ParticleManager {
  constructor(){
    this.parts = [];
  }

  // addPart(x,y,c,vx,vy,l,r){
  //   this.parts.push(new Particle(x,y,c,vx,vy,l,r));
  // }

  addPart(config){
    this.parts.push(new Particle(config.x,config.y,config.c,config.vx,config.vy,config.l,config.r) );
  }

  update(){
    this.parts.forEach((cv) => {
      cv.update();
    });
    this.parts = this.parts.filter((cv)=>{
      return cv.life>0;
    })
  }

  addForce(f){
    this.parts.forEach((cv) => {
      f(cv);
    });
  }

  draw(ctx){
    this.parts.forEach((cv) => {
      cv.draw(ctx);
    });
  }

}
