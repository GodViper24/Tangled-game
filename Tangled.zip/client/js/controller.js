/*
Controller.js - (module)
  Used to interface between the DOM and the game engine.
  Handles keyboard input and mouse position / clicks over "display"(canvas)
By: Josh Sanders
Last edit: 11/21/21
*/


const keyStates = {};
const firstPress = {};
const keyBind = {};
let mouseX = 0;
let mouseY = 0;
let mouseDown = false;
let display = false;

window.addEventListener("keydown",(e)=>{ keyStates[e.key] = true; if(!firstPress[e.key]){  firstPress[e.key] = true; }     });
window.addEventListener("keyup",(e)=>{ keyStates[e.key] = false; });


function getMousePos(evt) {
  if(!display){ return { x:0, y:0 }; }
  var rect = display.getBoundingClientRect();
  return {
      x: evt.clientX - rect.left,
      y: evt.clientY - rect.top
  }
}

const handleMouseMove = function(e){
  let p = getMousePos(e);
  mouseX = Math.floor(p.x);
  mouseY = Math.floor(p.y);

}


window.addEventListener("mousemove",handleMouseMove);
window.onmousedown = ()=>{ mouseDown = true; };
window.onmouseup = ()=>{ mouseDown = false; };

//touch events
window.ontouchstart = (e)=>{
  mouseDown = true;
  let mod = { clientX: e.touches[0].clientX, clientY: e.touches[0].clientY };
  handleMouseMove(mod);
};
window.ontouchend = ()=>{ mouseDown = false; mouseX = -1; mouseY=-1;}
window.ontouchmove = (e)=>{
  let mod = { clientX: e.touches[0].clientX, clientY: e.touches[0].clientY };
  handleMouseMove(mod);
}

export default class Controller {
  constructor(dis){
    display = dis;
  }

  addBind(id,key){
    keyBind[id] = key;
  }

  checkFirstPress(key){ return firstPress[key] || false; }
  clearFirstPress(){ Object.keys(firstPress).forEach( k =>{
    firstpress[k] = false;
  }) }

  checkBind(id){ return keyStates[keyBind[id]] | false; }

  getKey(key){ return keyStates[key] | false; }

  getKeys(keys){
    let out = {};
    keys.forEach((cv)=>{
      out[cv] = keyStates[cv] | false;
    });
    return out;
  }

    getMouse(DM){
    let s = DM.getScale();
    return { x:mouseX/s.x, y:mouseY/s.y, state:mouseDown };
    }
}
