/*
Display.js - (module)
  Used to interface between canvas and the game engine.
  Utilizes a double buffer.
By: Josh Sanders
Last edit: 3/18/21
*/

let scale = { x:1,y:1 };

export default class DisplayMan{
  constructor(canvas){

    this.canvas = canvas;
    this.ctx = this.canvas.getContext("2d");
    this.DB = document.createElement("canvas");
    this.DB.width = this.canvas.width;
    this.DB.height = this.canvas.height;
    this.DBctx = this.DB.getContext("2d");

    window.addEventListener('resize', this.resizeCanvas, false);
    this.resizeCanvas()
  }

  drawImage(data){
    this.DBctx.drawImage(data.img,data.x,data.y);
  }

  getScale(){ return scale; }

  resizeCanvas() {
    const canvasRatio = this.canvas.height / this.canvas.width;
    const windowRatio = window.innerHeight / window.innerWidth;
    let width = 0;
    let height = 0;

    if (windowRatio < canvasRatio) {
        height = window.innerHeight;
        width = height / canvasRatio;
    } else {
        width = window.innerWidth;
        height = width * canvasRatio;
    }
    scale.x = (width) / 800 ;
    scale.y = (height) / 800 ;

    this.canvas.style.width = (width) + 'px';
    this.canvas.style.height = (height) + 'px';
  }


  update(){
    this.ctx.drawImage(this.DB,0,0);
  }
}
