/*
Engine.js - (module)
  Fixed Time Step update engine.
  Calls provided update and draw functions at rate specified in TimeStep
By: Josh Sanders
Last edit: 3/18/21
*/

const data = {
  accumulated_time: 0,
  afr: undefined, //Animation Frame Request
  time: 0,
  timeStep : 0,
  updated : false,
  updateList : [],
  drawList : []
};

export default class Engine{
  constructor(TimeStep){
    data.timeStep = TimeStep;
  }

  addUpdateFunction(func){ data.updateList.push(func); }

  addDrawFunction(func){ data.drawList.push(func); }

  run(ts = 0){
    data.accumulated_time += ts - data.time;
    data.time = ts;
    if(data.accumulated_time > data.timeStep * 3 ){ data.accumulated_time = data.timeStep; }
    while(data.accumulated_time > data.timeStep){
      data.accumulated_time -= data.timeStep;
      data.updateList.forEach((cv)=>{ cv(ts); });
      data.updated = true;
    }
    if(data.updated){
      data.drawList.forEach((cv) => {
        cv();
        data.updated = false;
      });
    }
    data.afr = window.requestAnimationFrame((_ts)=>{ this.run(_ts); });
  }
}
