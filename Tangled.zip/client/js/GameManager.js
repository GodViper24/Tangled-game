import MersenneTwister from './mersenne.js';
import ParticleManager from "./parts.js";


class Node {

  constructor(x,y){
    this.x = x;
    this.y = y;
    this.r = 20;
    this.Fixed = false;
  }

  checkOver(loc){
      let rx = this.x - loc.x;
      let ry = this.y - loc.y;
      return Math.sqrt((rx*rx)+(ry*ry)) <= this.r;
    }

}

const sameSign = (a, b) => (a * b) > 0;
function intersect(x1, y1, x2, y2, x3, y3, x4, y4){
	var a1, a2, b1, b2, c1, c2;
	var r1, r2 , r3, r4;
	var denom, offset, num;

	// Compute a1, b1, c1, where line joining points 1 and 2
	// is "a1 x + b1 y + c1 = 0".
	a1 = y2 - y1;
	b1 = x1 - x2;
	c1 = (x2 * y1) - (x1 * y2);

	// Compute r3 and r4.
	r3 = ((a1 * x3) + (b1 * y3) + c1);
	r4 = ((a1 * x4) + (b1 * y4) + c1);

	// Check signs of r3 and r4. If both point 3 and point 4 lie on
	// same side of line 1, the line segments do not intersect.
	if ((r3 !== 0) && (r4 !== 0) && sameSign(r3, r4)){
		return 0; //return that they do not intersect
	}

	// Compute a2, b2, c2
	a2 = y4 - y3;
	b2 = x3 - x4;
	c2 = (x4 * y3) - (x3 * y4);

	// Compute r1 and r2
	r1 = (a2 * x1) + (b2 * y1) + c2;
	r2 = (a2 * x2) + (b2 * y2) + c2;

	// Check signs of r1 and r2. If both point 1 and point 2 lie
	// on same side of second line segment, the line segments do
	// not intersect.
	if ((r1 !== 0) && (r2 !== 0) && (sameSign(r1, r2))){
		return 0; //return that they do not intersect
	}

	//Line segments intersect: compute intersection point.
	denom = (a1 * b2) - (a2 * b1);

	if (denom === 0) {
    const xBetween = (x1 >= x3 && x1 <= x4 || x2 >= x3 && x2 <= x4 || x3 <= x1 && x3>=x2 );
    const yBetween = (y1 >= y3 && y1 <= y4 || y2 >= y3 && y2 <= y4 || y3 <= y1 && y3>=y2 );
    if (xBetween && yBetween ) {
      return 1;
    }
    return 0;
	}

	// lines_intersect
	return 1; //lines intersect, return true
}

function intersectAt(x1, y1, x2, y2, x3, y3, x4, y4) {

  // Check if none of the lines are of length 0
    if ((x1 === x2 && y1 === y2) || (x3 === x4 && y3 === y4)) {
        return false
    }

    let denominator = ((y4 - y3) * (x2 - x1) - (x4 - x3) * (y2 - y1));

  // Lines are parallel
    if (denominator === 0) {
        return false
    }

    let ua = ((x4 - x3) * (y1 - y3) - (y4 - y3) * (x1 - x3)) / denominator
    let ub = ((x2 - x1) * (y1 - y3) - (y2 - y1) * (x1 - x3)) / denominator

  // is the intersection along the segments
    if (ua < 0 || ua > 1 || ub < 0 || ub > 1) {
        return false
    }

  // Return a object with the x and y coordinates of the intersection
    let x = x1 + ua * (x2 - x1)
    let y = y1 + ua * (y2 - y1)

    return {x, y}
}

const MR = new MersenneTwister();
const PM = new ParticleManager();
/*
  config {
  nodeCount: Number > 2
  minLinks: Number >= 1
  useFixed: true/false
  randomSeed: number
}

*/

function convertTime(t){
  let min = Math.floor(t/(60000));
  let sec = Math.floor((t-(min*60000))/1000);
  return min+" : "+sec;
}

export default class GameManager {
  constructor(config){
    this.nodes = [];
    this.links = [];
    this.inter = [];
    this.interface = {
      drag: false,
      dragIndex: -1,
      clickFlag: false
    };
    this.gameState = "MainMenu"; // Init / MainMenu / Info / ActiveGame / CompletedGame
    this.config = config;
    this.curGameData = { moves:0, complete:false, topScore: -1,topTime: -1,topTimeRaw:-1, tag:"" }
    config.sck.on("Score",(Data)=>{
      this.curGameData.topScore = Data.score;
      this.curGameData.topTime = convertTime(parseInt(Data.time));
      this.curGameData.topTimeRaw = Data.time;
    });
  }
  genGame(tag,sel=-1){
    //Reset Data
    this.nodes = [];
    this.links = [];
    this.curGameData.moves = 0;
    this.curGameData.complete = false;
    this.curGameData.tag = tag;
    this.curGameData.topScore = -1;
    this.config.randomSeed = Math.floor(Math.random()*100);
    if(sel != -1){ this.config.randomSeed = sel; }
    this.config.sck.emit("GetScore",tag+this.config.randomSeed);
    MR.init_seed(this.config.randomSeed);
    //Place nodes randomly
    for(let i=0;i<this.config.nodeCount;i++){
      let x = 100 + Math.floor(MR.random_incl()*600);
      let y = 100 + Math.floor(MR.random_incl()*600);
      this.nodes.push(new Node(x,y));
    }
    //Create links
    this.nodes.forEach((cv, ind) => {
      let lst = this.nodes.map((x,ind)=>{ return ind; }); //Get list of indexes
      lst.splice(ind,1); //Remove the cur index
      lst.sort((a,b)=>{
        if( MR.random_incl() > 0.5 ) { return 1; }
        return -1;
      }) //Randomize indexes
      let connects = 0;
      for(let i=0;i<lst.length;i++){
        this.links.push({ A:ind, B:lst[i], F: false });
        if(!this.updateLinks()){ //new link created an overlap
          this.links.pop();
        } else {
          connects +=1;
          if(connects == this.config.minLinks){ break; }
        }
      }
    });
    //Move Nodes into circle pattern
    let step = (Math.PI*2)/this.config.nodeCount;
    this.nodes.forEach((cv, ind) => {
      cv.x = 400 + (Math.cos(step*ind)*300);
      cv.y = 400 + (Math.sin(step*ind)*300);
    });
    if(this.config.useFixed){
      this.nodes[0].Fixed = true;
      this.nodes[0].x = 400;
      this.nodes[0].y = 400;
    }
    
    this.gameStartTime = Date.now(); //Start Game Timer
    this.updateLinks();
  }
  
  updateLinks(){
    if( this.links.length<2 ){ return true; }
    this.curGameData.complete = true;
    this.inter = [];
    for(let i=0;i<this.links.length;i++){ this.links[i].F = false; }
    for(let a=0;a<this.links.length;a++){
      for(let b=0;b<this.links.length;b++){
        if( a != b ){
          let p1 = { x: this.nodes[this.links[a].A].x, y: this.nodes[this.links[a].A].y };
          let p2 = { x: this.nodes[this.links[a].B].x, y: this.nodes[this.links[a].B].y };
          let p3 = { x: this.nodes[this.links[b].A].x, y: this.nodes[this.links[b].A].y };
          let p4 = { x: this.nodes[this.links[b].B].x, y: this.nodes[this.links[b].B].y };
          //Check to see if these two lines share a nodes
          if( this.links[a].A != this.links[b].A && this.links[a].A != this.links[b].B && this.links[a].B != this.links[b].A && this.links[a].B != this.links[b].B ){ //they do not...
            //check if they intersect
            if(intersect(p1.x,p1.y,p2.x,p2.y,p3.x,p3.y,p4.x,p4.y) == 1 ){
              this.links[a].F = true;
              this.links[b].F = true;
              this.curGameData.complete = false;
              this.inter.push( intersectAt(p1.x,p1.y,p2.x,p2.y,p3.x,p3.y,p4.x,p4.y) );
            }
          }
        }
      }
    }
    if(this.curGameData.complete && this.gameState == "ActiveGame"){ this.gameFinishTime = Date.now(); };
    return this.curGameData.complete;
  }
  
  updateGame(Cont,DM){
    if(!this.curGameData.complete){
      if( this.gameState == "ActiveGame"){ this.curGameData.complete = this.updateLinks(); }
    }
    PM.update();
    if(this.curGameData.complete && (this.gameState == "ActiveGame") ){
      this.gameState = "CompletedGame";
      this.config.sck.emit("SetScore",{ GameID:this.curGameData.tag+this.config.randomSeed, Score:this.curGameData.moves, Time:this.gameFinishTime - this.gameStartTime });
    }
    let m = Cont.getMouse(DM);
    //let scaleData = DM.getScale();
    let scaledPosition = m; //{ x: Math.floor( m.x/scaleData.x ), y:  Math.floor( m.y/scaleData.y) };

    //------------  Main Menu Iterface -----------------

    if(this.gameState == "MainMenu"){
      if(m.state){
        if(scaledPosition.x>275 && scaledPosition.x<406 && scaledPosition.y>335 && scaledPosition.y<410 ){
          this.config.nodeCount = 10;
          this.config.minLinks = 2;
          this.config.useFixed = false;
          this.gameState = "ActiveGame";
          this.genGame("E");
          //this.mainMenu = false;
         } // Easy
        else if(scaledPosition.x>275 && scaledPosition.x<485 && scaledPosition.y>420 && scaledPosition.y<470 ){
          this.config.nodeCount = 15;
          this.config.minLinks = 2;
          this.config.useFixed = true;
          this.gameState = "ActiveGame";
          this.genGame("M");
         } // Med
        else if(scaledPosition.x>275 && scaledPosition.x<485 && scaledPosition.y>420 && scaledPosition.y<530 ){
          this.config.nodeCount = 15;
          this.config.minLinks = 3;
          this.config.useFixed = true;
          this.gameState = "ActiveGame";
          this.genGame("H");
         } // Hard
         else if(scaledPosition.x>243 && scaledPosition.x<490 && scaledPosition.y>564 && scaledPosition.y<625 ){
           this.gameState = "Info";
         }
      }
    }


    //---------------   Info Screen Interface  --------------------

    else if(this.gameState == "Info"){
      if(m.state){
        if(scaledPosition.x>350 && scaledPosition.x<430 && scaledPosition.y>700 && scaledPosition.y<738 ){ //Back
          this.gameState = "MainMenu";
        }
      }
    }

    else if( this.gameState == "ActiveGame" || this.gameState == "CompletedGame"){
      if(m.state){ //Mouse Down
        if(!this.interface.drag){

          for(let i=0;i<this.nodes.length;i++){ //Find node under mouse
            if(this.nodes[i].checkOver(scaledPosition) && !this.nodes[i].Fixed){
              this.interface.dragIndex = i;
              this.interface.drag = true;
              this.curGameData.moves += 1;
              break;
            }
          }

          // if(scaledPosition.x>66 && scaledPosition.x<276 && scaledPosition.y>730 && scaledPosition.y<790 && !this.interface.clickFlag){
          //   this.genGame(this.curGameData.tag);
          //   this.interface.clickFlag = true;
          //   this.gameState = "ActiveGame";
          // } //New Game Button
          // if(scaledPosition.x>440 && scaledPosition.x<710 && scaledPosition.y>730 && scaledPosition.y<790 ){ this.gameState = "MainMenu"; } //Main Menu
          if(scaledPosition.x>11 && scaledPosition.x<204 && scaledPosition.y>743 && scaledPosition.y<780 && !this.interface.clickFlag){ //New Game
            this.genGame(this.curGameData.tag);
            this.interface.clickFlag = true;
            this.gameState = "ActiveGame";
          } //New Game Button
          if(scaledPosition.x>540 && scaledPosition.x<775 && scaledPosition.y>743 && scaledPosition.y<780 ){ this.gameState = "MainMenu"; } //Main Menu
          if(scaledPosition.x>280 && scaledPosition.x<425 && scaledPosition.y>743 && scaledPosition.y<780 && !this.interface.clickFlag ){ //Restart
            this.genGame(this.curGameData.tag,this.config.randomSeed);
            this.interface.clickFlag = true;
            this.gameState = "ActiveGame";
          }
        }
        else {
          this.nodes[this.interface.dragIndex].x = scaledPosition.x;
          if( this.nodes[this.interface.dragIndex].x < 50 ){ this.nodes[this.interface.dragIndex].x =50; }
          else if( this.nodes[this.interface.dragIndex].x > 750 ){ this.nodes[this.interface.dragIndex].x = 750; }
          this.nodes[this.interface.dragIndex].y = scaledPosition.y;
          if( this.nodes[this.interface.dragIndex].y < 50 ){ this.nodes[this.interface.dragIndex].y =50; }
          else if( this.nodes[this.interface.dragIndex].y > 700 ){ this.nodes[this.interface.dragIndex].y = 700; }
        }
      } else { //Mouse Up
        this.interface.drag = false;
        this.interface.clickFlag = false;
      }
    }

    else if( this.gameState == "CompletedGame"){
      if(m.state){
        // if(scaledPosition.x>66 && scaledPosition.x<276 && scaledPosition.y>730 && scaledPosition.y<790 && !this.interface.clickFlag){
        //   this.genGame(this.curGameData.tag);
        //   this.interface.clickFlag = true;
        //   this.gameState == "ActiveGame";
        //   this.curGameData.complete = false;
        // } //New Game Button
        // if(scaledPosition.x>440 && scaledPosition.x<710 && scaledPosition.y>730 && scaledPosition.y<790 ){ 
        //   this.gameState = "MainMenu"; 
        //   this.interface.clickFlag = true; 
        //    this.curGameData.complete = false;
        //   } //Main Menu
        if(scaledPosition.x>11 && scaledPosition.x<204 && scaledPosition.y>743 && scaledPosition.y<780 && !this.interface.clickFlag){ //New Game
          this.genGame(this.curGameData.tag);
          this.interface.clickFlag = true;
        } //New Game Button
        if(scaledPosition.x>540 && scaledPosition.x<775 && scaledPosition.y>743 && scaledPosition.y<780 ){ this.gameState = "MainMenu"; } //Main Menu
        if(scaledPosition.x>280 && scaledPosition.x<425 && scaledPosition.y>743 && scaledPosition.y<780 && !this.interface.clickFlag ){ //Restart
          this.genGame(this.curGameData.tag,this.config.randomSeed);
          this.interface.clickFlag = true;
        };
      } else { //Mouse Up
        this.interface.drag = false;
        this.interface.clickFlag = false;
      }
    }

  }
  drawGame(AM,DM){
    let ctx = DM.DBctx;
    if( this.gameState == "MainMenu" ){
      DM.drawImage({ img:AM.getAsset("Menu") , x:0, y:0 });
      return;
    }

    if( this.gameState == "Info" ){
      DM.drawImage({ img:AM.getAsset("Info") , x:0, y:0 });
      return;
    }


    for(let i=0;i<this.nodes.length;i++){
      DM.drawImage({ img:AM.getAsset("NodeShadow") , x:this.nodes[i].x-30, y:this.nodes[i].y-30 });
      if(this.nodes[i].Fixed){
        ctx.beginPath();
        ctx.strokeStyle = "#A66";
        ctx.lineWidth = 4;
        ctx.arc(this.nodes[i].x,this.nodes[i].y,32.5,0,Math.PI*2);
        ctx.stroke();
        ctx.closePath();
      }
    }
    for(let i=0;i<this.links.length;i++){
      let blink = Math.floor(Math.random()*100);
      let blink2 = Math.floor(Math.random()*4);
      ctx.lineWidth = 12+blink2;
      ctx.strokeStyle = "rgba(150,150,150,0.2)";
      ctx.beginPath();
      ctx.moveTo(this.nodes[this.links[i].A].x,this.nodes[this.links[i].A].y);
      ctx.lineTo(this.nodes[this.links[i].B].x,this.nodes[this.links[i].B].y);
      ctx.stroke();
      ctx.lineWidth = 6;
      ctx.strokeStyle = "rgba(150,150,150,0.5)";
      ctx.stroke();
      ctx.lineWidth = 3;
      if(this.complete){ ctx.strokeStyle = "rgb(150,150,150)"; }
      else if(this.links[i].F){ ctx.strokeStyle = "rgb("+(155+blink)+",50,50)"; }
      else { ctx.strokeStyle = "rgb(50,"+(155+blink)+",50)"; }
      ctx.stroke();
      ctx.closePath();
    }

    for(let i=0;i<this.inter.length;i++){
      if(Math.random() < 0.2){ 
      
        PM.addPart({ x:this.inter[i].x, y:this.inter[i].y, c:"rgba(200,200,255,0.55)", vx:(Math.random()*6)-3, vy:(Math.random()*6)-3, l:10, r:3 } ); 
        }
    }
    PM.addForce((cv)=>{
      cv.r *= 0.9;
      cv.vx *= 0.9;
      cv.vy *= 0.9;
    });
    PM.draw(ctx);

    for(let i=0;i<this.nodes.length;i++){
      DM.drawImage({ img:AM.getAsset("Node") , x:this.nodes[i].x-20, y:this.nodes[i].y-20 });
    }
    DM.drawImage({ img:AM.getAsset("GM") , x:0, y:0 });
    if( this.curGameData.complete ){
      DM.drawImage({ img:AM.getAsset("Solved") , x:0, y:0 });
      ctx.font = "20px Georgia";
      ctx.fillStyle = "#FFF";
      ctx.fillText("Game ID: "+this.config.randomSeed, 10, 100);
      ctx.fillText("Moves: "+this.curGameData.moves+"   Time: "+convertTime(this.gameFinishTime-this.gameStartTime), 10, 140);
      if(this.curGameData.topScore != -1){
        ctx.fillText("Top Score: "+this.curGameData.topScore+" Time: "+this.curGameData.topTime, 10, 180);
        if(this.curGameData.moves < this.curGameData.topScore || (this.curGameData.moves == this.curGameData.topScore && (this.gameFinishTime-this.gameStartTime) < this.curGameData.topTimeRaw )){
          ctx.fillText("New Top Score!!!", 10, 210);
        }
      }
      return;
    } else { //Game not complete
      ctx.font = "20px Georgia";
      ctx.fillStyle = "#000";
      if(this.curGameData.topScore != -1){
        ctx.fillText("Moves: "+this.curGameData.moves+"   Time: "+convertTime(Date.now()-this.gameStartTime), 10, 100);
        ctx.fillText("Top Score: "+this.curGameData.topScore+" : "+this.curGameData.topTime,10,130);
        //ctx.fillText("Moves: "+this.curGameData.moves+" ( Top Score: "+this.curGameData.topScore+")", 10, 100);
      }else {
      ctx.fillStyle = "#000";
      ctx.fillText("Moves: "+this.curGameData.moves+"   Time: "+convertTime(Date.now()-this.gameStartTime), 10, 100); }
    }

  }

}
