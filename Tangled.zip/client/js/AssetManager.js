/*
AssetManager.js - (module)
Simple asset loading and storage.
By: Josh Sanders
Last edit: 11/21/21
*/

const Assets = {};

export default class AssetMan {
  constructor(){
    this.loadingCnt = 0;
  }

  /*
  loadAsset(data,cb)
  cb = function(string){} // Called when asset is loaded
  data for images = { type:"Image", id:string, path:string }
  data for Sound = { type:"Sound", id:string, loop:boolean, autoplay:boolean, volume:Number(0.0-1.0), path:string }; //Uses Howler Lib for audio
  */

  loadAsset(data,cb){
    if(data.type=="Image"){
      Assets[data.id] = new Image();
      Assets[data.id].src = data.path;
      Assets[data.id].addEventListener("load",()=>{ this.loadingCnt-=1; cb(data.id); });
    } else if( data.type=="Sound") {
      Assets[data.id] = new Howl({ src:data.path, loop:data.loop, autoplay: data.auto, volume: data.volume });
      Assets[data.id].once('load',()=>{ this.loadingCnt -=1;  cb(data.id); });
    }
  }

  assignAsset(data,id){ Assets[id]=data; }

  batchLoad(data,cb){
    let cnt = data.length;
    data.forEach((cv)=>{
      this.loadAsset(cv,(id)=>{  cnt-=1; if(cnt==0){ cb(); }; });
    });
  }

  getAsset(ID){ return Assets[ID]; }

  loading(){ return !this.loadingCnt; }
}
